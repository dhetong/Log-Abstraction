A log abstraction method
